var Discord = require('discord.io');
var logger = require('winston');
var auth = require('./auth.json');

// Configure logger settings
logger.remove(logger.transports.Console);
logger.add(logger.transports.Console, {
    colorize: true
});
logger.level = 'debug';
// Initialize Discord Bot
var bot = new Discord.Client({
   token: auth.token,
   autorun: true
});
bot.on('ready', function (evt) {
    logger.info('Connected');
    logger.info('Logged in as: ');
    logger.info(bot.username + ' - (' + bot.id + ')');
});


bot.on("message", function (user, userID, channelID, message, rawEvent){
	
	//PREFIXES-----------------------------------------
	if (message.substring(0, 2) == "a;") { 
        var arguments = message.substring(2).split(" ");
        var command = arguments[0]; 
        arguments = arguments.splice(2);
	};
	//--------------------------------------------------
    
  //VARS-----------------------------
  var serverID = bot.channels[channelID].guild_id;
   

  //COMMANDS--------------------------
  
    if(command == "presence" && userID != '228872946557386752'){
	bot.sendMessage({
		to:channelID,
    message:"I'm sorry but you do not have permission to use that command"
  });
}else if(command == "presence" && userID == '228872946557386752'){
	var presence = message.substring(';presence '.length)
/*	var defaultPresenceMSG = 'a;help'
	presence = var presence
	defaultPresenceMSG = presence*/
		bot.setPresence ({
    game:{
    	name: presence
    }
  }, (err, res) => { console.log(err); });
  	bot.sendMessage({
    	to:channelID,
      message:"Success!"
  });
};


	
	if(command == "great"){
    	bot.sendMessage({
        	to: channelID,
        	message:"Axel is good, Axel is great!"
    	});
	};
	
	if(command == "best"){
    	bot.sendMessage({
      	  to: channelID,
        	message:"I agree, Axel is the best!"
		});
	};
	
	if(command == "axeldab"){
  	  bot.sendMessage({
    	    to: channelID,
      	  message:"Axel dabbed and the whole world was amazed"
		});
	};
	
	if(command == "normydab"){
			bot.sendMessage({
				to: channelID,
				message:"You dabbed... If you call that a Dab that is."
		});
	};
	
	if(command == "help"){
			bot.sendMessage({
				to: channelID,
				message:"```You wanted help? Well here it is: \n a;running?: for those who are blind \n a;love: I love you in most circumstances. \n a;great: Greatness awaits me \n a;axeldab: Axel Dabs it hard \n a;normydab: The normal Dab. \n ```"
  		});
	};
  if(command =="love"){
		bot.sendMessage({
			to: channelID,
			message:"You may love Axel, but under most circumstances Axel does not love you."
		});
	};
	if(command =="running?"){
		bot.sendMessage({
			to: channelID,
			message:"Currently running"
		});
	};
});
